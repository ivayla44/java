package main.java.order.ingredients;

public class Topping extends Ingredient {
    public Topping(String name) {
        super(name);
    }
}
