package main.java.farm.crops;

public class FarmCrop extends Crop {
    public FarmCrop(String name, int ripeAge) {
        super(name, ripeAge);
    }

    public FarmCrop(String name, int age, int ripeAge) {
        super(name, age, ripeAge);
    }
}
