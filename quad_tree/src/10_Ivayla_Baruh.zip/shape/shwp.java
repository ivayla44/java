package shape;

public interface shwp {
    Point[] get_points();
}
