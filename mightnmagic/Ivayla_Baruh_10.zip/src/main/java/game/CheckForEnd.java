package main.java.game;

public interface CheckForEnd {
    public boolean checkForEnd();
}
