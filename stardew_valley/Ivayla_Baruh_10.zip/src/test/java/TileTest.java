package test.java;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TileTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void isFree() {
    }

    @Test
    void hasCrop() {
    }

    @Test
    void clearCrop() {
    }

    @Test
    void block() {
    }

    @Test
    void till() {
    }

    @Test
    void sowSeed() {
    }

    @Test
    void plantTree() {
    }

    @Test
    void applyTool() {
    }
}