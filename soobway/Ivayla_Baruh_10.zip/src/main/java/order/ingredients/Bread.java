package main.java.order.ingredients;

public class Bread extends Ingredient {
    public Bread(String name) {
        super(name);
    }
}
