package options_interfaces;
import game.*;

public interface IReward {
    void reward(Player player);
}
