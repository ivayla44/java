package main.java.order.ingredients;

public class Cheese extends Ingredient {
    public Cheese(String name) {
        super(name);
    }
}
