package test.java;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CropTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void isRipe() {
    }

    @Test
    void processNextDay() {
    }
}