package main.java.order.ingredients;

public class Sauce extends Ingredient {
    public Sauce(String name) {
        super(name);
    }
}
