package options_interfaces;
import game.*;

public interface IOptional {
    boolean test(Player player);
}
