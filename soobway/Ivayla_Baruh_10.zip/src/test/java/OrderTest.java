package test.java;

import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.Test
    void isValid() {
    }
}