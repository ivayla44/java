package main.java.order.ingredients;

public class Meat extends Ingredient{
    public Meat(String name) {
        super(name);
    }
}
