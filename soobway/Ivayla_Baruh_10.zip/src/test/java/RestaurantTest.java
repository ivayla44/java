package test.java;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RestaurantTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void addCook() {
    }

    @Test
    void removeCook() {
    }

    @Test
    void addOrder() {
    }

    @Test
    void finalizeOrder() {
    }

    @Test
    void shutdown() {
    }
}