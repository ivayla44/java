package main.java.farm.crops;

public class FarmTree extends Crop {
    public FarmTree(String name, int ripeAge) {
        super(name, ripeAge);
    }

    public FarmTree(String name, int age, int ripeAge) {
        super(name, age, ripeAge);
    }
}
