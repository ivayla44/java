package options_interfaces;
import game.*;

public interface IRequirement {
    void take(Player player);
}
